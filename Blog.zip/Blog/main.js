const navItems = document.querySelector('.nav_items');
const openNavBtn = document.querySelector('#open_nav_items');
const closeNavBtn = document.querySelector('#close_nav_items');

const openNav=()=>{
    navItems.style.display='flex';
    openNavBtn.style.display='none';
    closeNavBtn.style.display='inline-block';
}

openNavBtn.addEventListener('click',openNav);
closeNavBtn.addEventListener('click',closeNav);
